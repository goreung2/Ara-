from __future__ import annotations

import functools

from .errors import AraError
from ._utils import _find_channel, _permission_message


# ============================================================
# nsfw_only
# ============================================================


def nsfw_only(func):
    """
    NSFW로 지정된 채널에서만 사용 가능한 명령어.
    """

    @functools.wraps(func)
    async def wrapper(
        *args,
        **kwargs,
    ):

        channel = _find_channel(
            args,
            kwargs,
        )

        is_nsfw = getattr(
            channel,
            "is_nsfw",
            None,
        )

        if not callable(is_nsfw) or not is_nsfw():

            raise AraError(
                _permission_message(
                    func,
                    "nsfw",
                )
            )

        return await func(
            *args,
            **kwargs,
        )

    return wrapper


__all__ = [
    "nsfw_only",
]
