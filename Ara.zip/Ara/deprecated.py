from __future__ import annotations

import functools
import inspect
import warnings


# ============================================================
# Deprecated
# ============================================================


def deprecated(
    reason: str | None = None,
    *,
    replacement: str | None = None,
):
    """
    함수가 더 이상 사용되지 않음을 경고한다 (DeprecationWarning).

    사용 예:

        @Ara.deprecated("v2에서 제거될 예정입니다.", replacement="new_command")
        async def old_command(ctx):
            ...
    """

    def decorator(func):

        text = f"{func.__qualname__}는 더 이상 사용되지 않습니다."

        if reason:
            text += f" {reason}"

        if replacement:
            text += f" 대신 '{replacement}'를 사용하세요."

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(
                *args,
                **kwargs,
            ):

                warnings.warn(
                    text,
                    category=DeprecationWarning,
                    stacklevel=2,
                )

                return await func(
                    *args,
                    **kwargs,
                )

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(
            *args,
            **kwargs,
        ):

            warnings.warn(
                text,
                category=DeprecationWarning,
                stacklevel=2,
            )

            return func(
                *args,
                **kwargs,
            )

        return sync_wrapper

    return decorator


__all__ = [
    "deprecated",
]
