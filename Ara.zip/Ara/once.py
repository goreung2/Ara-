from __future__ import annotations

import functools
import inspect


# ============================================================
# Once
# ============================================================


def once(func):
    """
    함수를 최초 1회만 실제로 실행하고,
    이후 호출에는 첫 실행 결과를 그대로 반환한다.

    on_ready에서 초기화 로직을 한 번만 실행하고 싶을 때 유용
    (discord.py의 on_ready는 재연결마다 여러 번 호출될 수 있다).

    사용 예:

        @bot.event
        @Ara.once
        async def on_ready():
            print("봇 최초 준비 완료")
    """

    state = {
        "called": False,
        "result": None,
    }

    if inspect.iscoroutinefunction(func):

        @functools.wraps(func)
        async def async_wrapper(
            *args,
            **kwargs,
        ):

            if state["called"]:
                return state["result"]

            state["called"] = True

            state["result"] = await func(
                *args,
                **kwargs,
            )

            return state["result"]

        return async_wrapper

    @functools.wraps(func)
    def sync_wrapper(
        *args,
        **kwargs,
    ):

        if state["called"]:
            return state["result"]

        state["called"] = True

        state["result"] = func(
            *args,
            **kwargs,
        )

        return state["result"]

    return sync_wrapper


__all__ = [
    "once",
]
