from __future__ import annotations

from .errors import AraError
from .cog_load import cog_load
from .retry import retry
from .ignore_error import ignore_error
from .log import log
from .measure import measure
from .typing import typing
from .auto_reply import auto_reply
from .is_owner import is_owner
from .is_guild import is_guild
from .is_admin import is_admin

from .cooldown import cooldown
from .dm_only import dm_only
from .has_role import has_role
from .has_permissions import has_permissions
from .nsfw_only import nsfw_only
from .confirm import confirm
from .catch import catch
from .lock import lock
from .cache import cache
from .debounce import debounce
from .once import once
from .require_env import require_env
from .deprecated import deprecated
from .rate_limit import rate_limit


# ============================================================
# Ara
# ============================================================


class Ara:

    AraError = AraError

    cog_load = staticmethod(cog_load)
    retry = staticmethod(retry)
    ignore_error = staticmethod(ignore_error)
    log = staticmethod(log)
    measure = staticmethod(measure)
    typing = staticmethod(typing)
    auto_reply = staticmethod(auto_reply)
    is_owner = staticmethod(is_owner)
    is_guild = staticmethod(is_guild)
    is_admin = staticmethod(is_admin)

    cooldown = staticmethod(cooldown)
    dm_only = staticmethod(dm_only)
    has_role = staticmethod(has_role)
    has_permissions = staticmethod(has_permissions)
    nsfw_only = staticmethod(nsfw_only)
    confirm = staticmethod(confirm)
    catch = staticmethod(catch)
    lock = staticmethod(lock)
    cache = staticmethod(cache)
    debounce = staticmethod(debounce)
    once = staticmethod(once)
    require_env = staticmethod(require_env)
    deprecated = staticmethod(deprecated)
    rate_limit = staticmethod(rate_limit)


# ============================================================
# Export
# ============================================================


__all__ = [
    "Ara",
    "AraError",
]
