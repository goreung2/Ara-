from __future__ import annotations

import functools
import inspect
import logging
import time


# ============================================================
# Measure
# ============================================================


def measure(
    func=None,
    *,
    log: bool = True,
):
    """
    실행시간 측정.

    @Ara.measure

    또는

    @Ara.measure(log=False)
    """

    def decorate(target):

        target_logger = logging.getLogger(
            target.__module__
        )

        if inspect.iscoroutinefunction(target):

            @functools.wraps(target)
            async def async_wrapper(
                *args,
                **kwargs,
            ):

                started = time.perf_counter()

                try:

                    return await target(
                        *args,
                        **kwargs,
                    )

                finally:

                    elapsed = (
                        time.perf_counter()
                        - started
                    )

                    if log:

                        target_logger.info(
                            "[Ara] %s 실행시간: %.4fs",
                            target.__qualname__,
                            elapsed,
                        )

            return async_wrapper

        @functools.wraps(target)
        def sync_wrapper(
            *args,
            **kwargs,
        ):

            started = time.perf_counter()

            try:

                return target(
                    *args,
                    **kwargs,
                )

            finally:

                elapsed = (
                    time.perf_counter()
                    - started
                )

                if log:

                    target_logger.info(
                        "[Ara] %s 실행시간: %.4fs",
                        target.__qualname__,
                        elapsed,
                    )

        return sync_wrapper

    if func is not None:

        return decorate(func)

    return decorate


__all__ = [
    "measure",
]
