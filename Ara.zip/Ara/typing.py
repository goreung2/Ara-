from __future__ import annotations

import functools
import inspect


# ============================================================
# Typing
# ============================================================


def typing(func):
    """
    Discord typing 상태를 표시.
    """

    if not inspect.iscoroutinefunction(func):

        raise TypeError(
            "@Ara.typing은 async 함수에서만 "
            "사용할 수 있습니다."
        )

    @functools.wraps(func)
    async def wrapper(
        *args,
        **kwargs,
    ):

        ctx = next(
            (
                value
                for value
                in (*args, *kwargs.values())
                if (
                    hasattr(value, "typing")
                    and hasattr(value, "send")
                )
            ),
            None,
        )

        if ctx is not None:

            async with ctx.typing():

                return await func(
                    *args,
                    **kwargs,
                )

        return await func(
            *args,
            **kwargs,
        )

    return wrapper


__all__ = [
    "typing",
]
