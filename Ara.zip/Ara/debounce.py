from __future__ import annotations

import functools
import inspect
import time

from typing import Any


# ============================================================
# Debounce
# ============================================================


def debounce(seconds: float):
    """
    마지막 호출로부터 일정 시간이 지나지 않으면 실행을 건너뛴다.
    (연속 이벤트, on_message 스팸 등에 유용)

    실행이 스킵되면 None을 반환한다.

    사용 예:

        @Ara.debounce(2)
        async def on_typing_notify(channel):
            await channel.send("...")
    """

    def decorator(func):

        state: dict[str, float] = {"last": 0.0}

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(
                *args: Any,
                **kwargs: Any,
            ):

                now = time.monotonic()

                if now - state["last"] < seconds:
                    return None

                state["last"] = now

                return await func(
                    *args,
                    **kwargs,
                )

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(
            *args: Any,
            **kwargs: Any,
        ):

            now = time.monotonic()

            if now - state["last"] < seconds:
                return None

            state["last"] = now

            return func(
                *args,
                **kwargs,
            )

        return sync_wrapper

    return decorator


__all__ = [
    "debounce",
]
