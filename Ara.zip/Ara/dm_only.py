from __future__ import annotations

import functools

from .errors import AraError
from ._utils import _find_guild, _permission_message


# ============================================================
# dm_only
# ============================================================


def dm_only(func):
    """
    DM(개인 메시지)에서만 사용 가능한 명령어.

    is_guild와 반대.

    ARA.ini:

    [permissions]
    dm = 이 명령어는 DM에서만 사용할 수 있습니다.
    """

    @functools.wraps(func)
    async def wrapper(
        *args,
        **kwargs,
    ):

        guild = _find_guild(
            args,
            kwargs,
        )

        if guild is not None:

            raise AraError(
                _permission_message(
                    func,
                    "dm",
                )
            )

        return await func(
            *args,
            **kwargs,
        )

    return wrapper


__all__ = [
    "dm_only",
]
