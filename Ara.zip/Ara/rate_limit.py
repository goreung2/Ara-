from __future__ import annotations

import asyncio
import functools
import inspect
import time

from .errors import AraError


# ============================================================
# Rate Limit
# ============================================================


def rate_limit(
    calls: int,
    per: float,
    *,
    wait: bool = True,
):
    """
    토큰 버킷 방식으로 함수 호출 빈도를 제한한다.
    외부 API 호출량 제한(예: 분당 60회)을 지킬 때 유용하다.

    calls:
        기간(per) 동안 허용되는 최대 호출 횟수.

    per:
        기간 (초).

    wait:
        True (기본)  - 토큰이 찰 때까지 대기 후 실행.
        False        - 토큰이 없으면 즉시 AraError 발생.

    사용 예:

        @Ara.rate_limit(calls=60, per=60)   # 분당 60회
        async def call_external_api():
            ...

        @Ara.rate_limit(calls=5, per=10, wait=False)
        async def send_alert():
            ...
    """

    def decorator(func):

        tokens = calls
        last_refill = time.monotonic()
        async_lock = asyncio.Lock()

        def refill():

            nonlocal tokens, last_refill

            now = time.monotonic()

            elapsed = now - last_refill

            regenerated = elapsed * (calls / per)

            if regenerated >= 1:

                tokens = min(
                    calls,
                    tokens + regenerated,
                )

                last_refill = now

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(
                *args,
                **kwargs,
            ):

                nonlocal tokens

                async with async_lock:

                    refill()

                    while tokens < 1:

                        if not wait:

                            raise AraError(
                                "호출 한도를 초과했습니다. "
                                "잠시 후 다시 시도해주세요."
                            )

                        await asyncio.sleep(
                            per / calls
                        )

                        refill()

                    tokens -= 1

                return await func(
                    *args,
                    **kwargs,
                )

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(
            *args,
            **kwargs,
        ):

            nonlocal tokens

            refill()

            while tokens < 1:

                if not wait:

                    raise AraError(
                        "호출 한도를 초과했습니다. "
                        "잠시 후 다시 시도해주세요."
                    )

                time.sleep(per / calls)

                refill()

            tokens -= 1

            return func(
                *args,
                **kwargs,
            )

        return sync_wrapper

    return decorator


__all__ = [
    "rate_limit",
]
