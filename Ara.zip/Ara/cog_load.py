from __future__ import annotations

import functools

from typing import Iterable

from .errors import AraError
from ._utils import _find_bot


# ============================================================
# Cog Load
# ============================================================


def cog_load(
    *,
    cogs: str | Iterable[str] = "all",
):
    """
    함수 실행 전에 지정된 Cog를 reload한다.

    cogs="all"
        모든 Cog reload.

    cogs="admin"
        admin Cog reload.

    cogs=["admin", "utility"]
        여러 Cog reload.

    cogs="all"이 아닌 경우
    현재 함수가 속한 Cog는 reload하지 않는다.
    """

    def decorator(func):

        @functools.wraps(func)
        async def wrapper(
            *args,
            **kwargs,
        ):

            bot = _find_bot(
                args,
                kwargs,
            )

            if bot is None:

                raise AraError(
                    "Discord Bot을 찾을 수 없습니다."
                )

            extensions = getattr(
                bot,
                "extensions",
                {},
            )

            current_module = getattr(
                func,
                "__module__",
                None,
            )

            # --------------------------------------------
            # Reload 대상
            # --------------------------------------------

            if cogs == "all":

                targets = list(
                    extensions.keys()
                )

            elif isinstance(
                cogs,
                str,
            ):

                targets = [cogs]

            else:

                targets = list(cogs)

            # --------------------------------------------
            # Reload
            # --------------------------------------------

            for target in targets:

                extension = str(target)

                # "admin"
                # -> "cogs.admin"
                if extension not in extensions:

                    shorthand = (
                        f"cogs.{extension}"
                    )

                    if shorthand in extensions:

                        extension = shorthand

                if extension not in extensions:

                    raise AraError(
                        f"Cog '{target}'을 "
                        "찾을 수 없습니다."
                    )

                # 자기 자신 제외
                if (
                    cogs != "all"
                    and extension == current_module
                ):

                    continue

                try:

                    await bot.reload_extension(
                        extension
                    )

                except Exception as error:

                    raise AraError(
                        f"Cog '{extension}' "
                        "reload에 실패했습니다.",
                        original=error,
                    ) from error

            return await func(
                *args,
                **kwargs,
            )

        return wrapper

    return decorator


__all__ = [
    "cog_load",
]
