from __future__ import annotations

import functools
import inspect
import os

from .errors import AraError


# ============================================================
# Require Env
# ============================================================


def require_env(*names: str):
    """
    함수 실행 전, 지정한 환경변수가 모두 설정되어 있는지 확인한다.
    누락된 값이 있으면 AraError를 발생시켜 조기에 실패시킨다.

    사용 예:

        @Ara.require_env("OPENAI_API_KEY", "DATABASE_URL")
        async def call_ai(prompt: str):
            ...
    """

    def decorator(func):

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(
                *args,
                **kwargs,
            ):

                missing = [
                    name
                    for name in names
                    if not os.environ.get(name)
                ]

                if missing:

                    raise AraError(
                        "다음 환경변수가 설정되지 않았습니다: "
                        + ", ".join(missing)
                    )

                return await func(
                    *args,
                    **kwargs,
                )

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(
            *args,
            **kwargs,
        ):

            missing = [
                name
                for name in names
                if not os.environ.get(name)
            ]

            if missing:

                raise AraError(
                    "다음 환경변수가 설정되지 않았습니다: "
                    + ", ".join(missing)
                )

            return func(
                *args,
                **kwargs,
            )

        return sync_wrapper

    return decorator


__all__ = [
    "require_env",
]
