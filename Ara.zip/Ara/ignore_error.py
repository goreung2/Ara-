from __future__ import annotations

import asyncio
import functools
import inspect

from typing import Any


# ============================================================
# Ignore Error
# ============================================================


def ignore_error(
    *exceptions: type[BaseException],
    default: Any = None,
):
    """
    지정된 예외를 무시한다.

    @Ara.ignore_error

    또는

    @Ara.ignore_error(
        ValueError,
        default=False,
    )
    """

    handled = (
        exceptions
        or (Exception,)
    )

    def decorator(func):

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(
                *args,
                **kwargs,
            ):

                try:

                    return await func(
                        *args,
                        **kwargs,
                    )

                except asyncio.CancelledError:

                    raise

                except handled:

                    return default

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(
            *args,
            **kwargs,
        ):

            try:

                return func(
                    *args,
                    **kwargs,
                )

            except handled:

                return default

        return sync_wrapper

    return decorator


__all__ = [
    "ignore_error",
]
