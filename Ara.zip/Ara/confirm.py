from __future__ import annotations

import asyncio
import functools
import inspect

from ._utils import _find_respondable, _find_member, _reply


# ============================================================
# Confirm
# ============================================================


def confirm(
    prompt: str = "정말 진행하시겠습니까? (yes/no)",
    *,
    timeout: float = 30.0,
    cancel_message: str = "취소되었습니다.",
    timeout_message: str = "시간이 초과되어 취소되었습니다.",
):
    """
    실행 전 사용자에게 확인을 요청한다.
    "yes" / "y" 로 응답해야 실제 함수가 실행된다.

    Context 기반 커맨드에서만 동작한다 (ctx.bot이 필요).

    사용 예:

        @commands.command()
        @Ara.confirm("정말 서버의 모든 역할을 삭제할까요?")
        async def purge_roles(ctx):
            ...
    """

    if timeout <= 0:

        raise ValueError(
            "timeout은 0보다 커야 합니다."
        )

    def decorator(func):

        if not inspect.iscoroutinefunction(func):

            raise TypeError(
                "@Ara.confirm은 async 함수에서만 "
                "사용할 수 있습니다."
            )

        @functools.wraps(func)
        async def wrapper(
            *args,
            **kwargs,
        ):

            target = _find_respondable(
                args,
                kwargs,
            )

            member = _find_member(
                args,
                kwargs,
            )

            bot = getattr(
                target,
                "bot",
                None,
            ) or getattr(
                target,
                "client",
                None,
            )

            await _reply(
                target,
                prompt,
            )

            if bot is None:

                # bot을 찾지 못하면 확인 절차를 건너뛴다.
                return await func(
                    *args,
                    **kwargs,
                )

            yes_words = ("yes", "y", "네", "예")
            no_words = ("no", "n", "아니오", "아니요")

            def check(message):

                if member is not None and (
                    message.author.id
                    != getattr(member, "id", None)
                ):
                    return False

                content = message.content.strip().lower()

                return content in yes_words or content in no_words

            try:

                reply = await bot.wait_for(
                    "message",
                    timeout=timeout,
                    check=check,
                )

            except asyncio.TimeoutError:

                await _reply(
                    target,
                    timeout_message,
                )

                return None

            if reply.content.strip().lower() in no_words:

                await _reply(
                    target,
                    cancel_message,
                )

                return None

            return await func(
                *args,
                **kwargs,
            )

        return wrapper

    return decorator


__all__ = [
    "confirm",
]
